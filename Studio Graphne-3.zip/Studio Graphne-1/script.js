// $(".cards").slick({
// //   centerMode: false,
// //   dots: true,
//   slidesToShow: 3,
//   slidesToScroll: 3,
//   arrows: true,
//   // overflow: false,
//   Infinity: true,
// //   responsive: [
// //     {
// //       breakpoint: 767,
// //       settings: {
// //         arrows: false,
// //         centerMode: false,
// //         Infinity: false,
// //         slidesToShow: 1,
// //       },
// //     },
// //   ],
// });

